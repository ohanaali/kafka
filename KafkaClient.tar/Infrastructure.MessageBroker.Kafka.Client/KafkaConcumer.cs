﻿using Confluent.Kafka;
using Infrastructure.MessageBroker.Kafka.Client.Abstracts;
using Infrastructure.MessageBroker.Kafka.Client.Config;
using Infrastructure.MessageBroker.Kafka.Client.Model;
using Infrastructure.Utils.Config;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Infrastructure.MessageBroker.Kafka.Client
{
    public class KafkaConcumer : IMessageBrokerConcumer
    {
        private readonly KafkaClientOptions Options;
        private readonly ILogger Log;
        private readonly ConfigrationMapping ConfMap;

        private CancellationToken CancellationToken;

        private Task Timer;
        private List<TopicPartitionOffset> OffSetsToCommit = new List<TopicPartitionOffset>();

        public IConsumer<string, string> ConcumerInstance { get; private set; }

        public KafkaConcumer(IServiceProvider serviceProvider)
        {
            // Load Configuration
            this.Options = new KafkaClientOptions();
            this.Options.LoadConfigSection<KafkaClientOptions>(serviceProvider.GetService<IConfiguration>());

            // Initialize local members (Log, IWebRestApiHandler)
            this.Log = serviceProvider.GetService<ILogger<KafkaProducer>>();

            this.ConfMap = new ConfigrationMapping();
        }

        public Task Concume(CancellationToken cancellationToken)
        {
            this.CancellationToken = cancellationToken;
            try
            {
                //this.Timer = Task.Run(TimerLoop);


                ConsumeResult<string, string> consumeResult = this.ConcumerInstance.Consume(cancellationToken);
                if (consumeResult.IsPartitionEOF)
                {
                    this.Log.LogDebug($"Reached end of topic {consumeResult.Topic}, partition {consumeResult.Partition}, offset {consumeResult.Offset}.");
                }
                else
                {
                    this.Log.LogInformation($"Consumed - Topic: {consumeResult.Topic}, Partition: {consumeResult.Partition}, Offset: {consumeResult.Offset}");
                    this.Log.LogDebug($"Consumed key: {consumeResult.Message.Key}, Consumed value: {consumeResult.Message.Value}");
                    this.OffSetsToCommit.Add(consumeResult.TopicPartitionOffset);
                    Thread.Sleep(1000 * 10); // Testings
                }

                if (consumeResult.Offset % this.Options.KafkaConcumer.CommitPeriod == 0)
                {
                    try
                    {
                        this.ConcumerInstance.Commit(consumeResult);
                        this.Log.LogInformation($"Commited - Topic: {consumeResult.Topic}, Partition: {consumeResult.Partition}, Offset: {consumeResult.Offset}");
                    }
                    catch (KafkaException e) { this.Log.LogError($"Commit error: {e.Error.Reason}"); }
                }

                Thread.Sleep(10000); // Testings

            }
            catch (ConsumeException e)
            {
                this.Log.LogError($"Consume error: {e.Error.Reason}");
            }

            return Task.CompletedTask;
        }

        private async Task TimerLoop()
        {
            while (!this.CancellationToken.IsCancellationRequested)
            {
                try
                {
                    await Task.WhenAny(Task.Delay(new TimeSpan(0, 0, 0, 30, 0))).ConfigureAwait(false);
                    await CommitOffsets(this.OffSetsToCommit).ConfigureAwait(false);
                    //this.Log.LogInformation($"message offset: {this.ConcumerInstance.Position()}");
                }
                catch (Exception)
                {
                    // intentionally ignored
                }
            }
        }
        private async Task CommitOffsets(IEnumerable<TopicPartitionOffset> offsets)
        {
            this.ConcumerInstance.Commit(offsets);
        }

        public void Initilize(string topicName)
        {
            ConsumerConfig consumerConfig = new ConsumerConfig
            {
                // Client Config
                BootstrapServers = this.Options.BrokerServers,
                SocketTimeoutMs = this.Options.SocketTimeout,
                ClientId = Dns.GetHostName(),
                ClientRack = this.Options.ClientRack,
                ReconnectBackoffMs = this.Options.ReconnectTimeout,
                // Concumer Config
                GroupId = this.Options.KafkaConcumer.GroupId,
                EnableAutoCommit = this.Options.KafkaConcumer.EnableAutoCommit,
                EnableAutoOffsetStore = this.Options.KafkaConcumer.EnableAutoOffsetStore,
                AllowAutoCreateTopics = this.Options.KafkaConcumer.AllowAutoCreateTopics,
                CheckCrcs = this.Options.KafkaConcumer.CheckCrcs,
                SessionTimeoutMs = this.Options.KafkaConcumer.SessionTimeout,
                AutoOffsetReset = this.ConfMap.ProducerAutoOffsetReset[this.Options.KafkaConcumer.AutoOffsetReset],
                MaxPollIntervalMs = this.Options.KafkaConcumer.MaxPollInterval,
                QueuedMinMessages = this.Options.KafkaConcumer.QueuedMinMessages
            };

            this.ConcumerInstance = new ConsumerBuilder<string, string>(consumerConfig)
                                        .SetErrorHandler((_, e) =>
                                        {
                                            OnError(e);
                                        })
                                        .SetStatisticsHandler((_, json) => this.Log.LogDebug($"Statistics: {json}"))
                                        .SetPartitionsAssignedHandler((c, partitions) =>
                                        {
                                            OnAssigned(partitions);
                                        })
                                        .SetPartitionsRevokedHandler((c, partitions) =>
                                        {
                                            OnRevoke(partitions);
                                            //this.ConcumerInstance.Commit();
                                        })
                                        .Build();

            this.ConcumerInstance.Subscribe(topicName);

        }

        private void OnError(Error e)
        {
            this.Log.LogError(e.Reason);
        }

        private void OnAssigned(List<TopicPartition> partitions)
        {
            this.Log.LogDebug($"Assigned partitions handler: [{string.Join(", ", partitions)}]");
            // possibly manually specify start offsets or override the partition assignment provided by
            // the consumer group by returning a list of topic/partition/offsets to assign to, e.g.:
            // return partitions.Select(tp => new TopicPartitionOffset(tp, externalOffsets[tp]));
        }

        private void OnRevoke(List<TopicPartitionOffset> partitions)
        {
            this.Log.LogInformation($"Revoking assignment handler: [{string.Join(", ", partitions)}]");
        }

        public void Close()
        {
            this.ConcumerInstance.Unsubscribe();
            this.ConcumerInstance.Close();
            this.ConcumerInstance.Dispose();
        }
    }
}
