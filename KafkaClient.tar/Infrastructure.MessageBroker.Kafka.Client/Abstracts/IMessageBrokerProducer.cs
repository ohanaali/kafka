﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.MessageBroker.Kafka.Client.Abstracts
{
    public interface IMessageBrokerProducer
    {
        void Initilize();

        Task Publish(string topicName, string messageValue, string messageKey = null);

        Task Publish<T1, T2>(string topicName, T1 messageValue, T2 messageKey);

        Task Publish<T>(string topicName, T messageValue);
    }
}
