﻿using Confluent.Kafka;
using Infrastructure.Utils.Config;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.MessageBroker.Kafka.Client.Config
{
    class KafkaConcumerOptions : BaseOptions
    {
        /// <summary>
        /// Client group id string. All clients sharing the same group.id belong to the same group.
        /// </summary>
        public string GroupId { get; set; }

        /// <summary>
        /// utomatically and periodically commit offsets in the background.
        /// Default: true
        /// </summary>
        public bool EnableAutoCommit { get; set; }

        /// <summary>
        /// Automatically store offset of last message provided to application. The offset
        /// store is an in-memory store of the next offset to (auto-)commit for each partition.
        /// Default: true
        /// </summary>
        public bool EnableAutoOffsetStore { get; set; }

        /// <summary>
        /// Allow automatic topic creation on the broker when subscribing to or assigning non-existent topics.
        /// Default: false
        /// </summary>
        public bool AllowAutoCreateTopics { get; set; }

        /// <summary>
        /// Verify CRC32 of consumed messages, ensuring no on-the-wire or on-disk corruption
        /// to the messages occurred. This check comes at slightly increased CPU usage.
        /// Default: false
        /// </summary>
        public bool CheckCrcs { get; set; }

        /// <summary>
        /// Client group session and failure detection timeout. The consumer sends periodic
        /// heartbeats (heartbeat.interval.ms) to indicate its liveness to the broker.
        /// If no hearts are received by the broker for a group member within the session timeout,
        /// the broker will remove the consumer from the group and trigger a rebalance.
        /// Default: 10000
        /// </summary>
        public int SessionTimeout { get; set; }

        /// <summary>
        /// Action to take when there is no initial offset in offset store or the desired offset is out of range
        /// 'earliest' - automatically reset the offset to the smallest offset
        /// 'latest' - automatically reset the offset to the largest offset
        /// 'error' - trigger an error which is retrieved by consuming messages and checking 'message->err'.
        /// Default: largest
        /// </summary>
        public string AutoOffsetReset { get; set; }

        /// <summary>
        /// Maximum allowed time between calls to consume messages for high-level consumers.
        /// If this interval is exceeded the consumer is considered failed and the group will
        /// rebalance in order to reassign the partitions to another consumer group member.
        /// Default: 300000
        /// </summary>
        public int MaxPollInterval { get; set; }

        /// <summary>
        /// Minimum number of messages per topic+partition librdkafka tries to maintain in the local consumer queue.
        /// Default: 100000
        /// </summary>
        public int QueuedMinMessages { get; set; }

        /// <summary>
        /// The period which the consumer send commit method to the kafka cluster.
        /// The Commit method sends a "commit offsets" request to the Kafka cluster and synchronously waits for the response.
        /// This is very slow compared to the rate at which the consumer is capable of consuming messages.
        /// A high performance application will typically commit offsets relatively infrequently and be designed handle
        /// duplicate messages in the event of failure.
        /// </summary>
        public int CommitPeriod { get; set; }

        /// <summary>
        /// Name of partition assignment strategy to use when elected group leader assigns partitions to group members.
        /// Range - Assigns to each consumer a consecutive subset of partitions from each topic it subscribes to.        
        /// Roundrobin - Takes all the partitions from all subscribed topics and assigns them to consumers sequentially, one by one.
        /// </summary>
        public PartitionAssignmentStrategy PartitionAssignmentStrategy { get; internal set; } = PartitionAssignmentStrategy.Range;
    }
}
