﻿using Confluent.Kafka;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.MessageBroker.Kafka.Client.Model
{
    public class ConfigrationMapping
    {
        public Dictionary<string, Acks> ClientAcks = new Dictionary<string, Acks>()
        {
            {"None", Acks.None}, {"One",  Acks.Leader}, {"All", Acks.All}
        };

        public Dictionary<string, Partitioner> ProducerPartitioner = new Dictionary<string, Partitioner>()
        {
            {"random", Partitioner.Random },
            {"consistent", Partitioner.Consistent },
            {"consistent_random" , Partitioner.ConsistentRandom },
        };

        public Dictionary<string, AutoOffsetReset> ProducerAutoOffsetReset = new Dictionary<string, AutoOffsetReset>()
        {
            {"earliest", AutoOffsetReset.Earliest },
            {"error", AutoOffsetReset.Error },
            {"latest" , AutoOffsetReset.Latest },
        };
    }
}
