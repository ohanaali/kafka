﻿using Infrastructure.Utils.Config;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.MessageBroker.Kafka.Client.Config
{
    public class KafkaProducerOptions : BaseOptions
    {
        /// <summary>
        /// This value is only enforced locally and limits the time a produced message waits for successful delivery.
        /// A time of 0 is infinite. This is the maximum time librdkafka may use to deliver a message (including retries).
        /// Delivery error occurs when either the retry count or the message timeout are exceeded.
        /// Default: 30000
        /// </summary>
        public int MessageTimeout { get; set; }

        /// <summary>
        /// How many times to retry sending a failing Message.
        /// Default: 2
        /// </summary>
        public int MessageSendMaxRetries { get; set; }

        /// <summary>
        /// Partitioner Options:
        /// `random` - random distribution,
        /// 'consistent` - CRC32 hash of key (Empty and NULL keys are mapped to single partition),
        /// `consistent_random` - CRC32 hash of key (Empty and NULL keys are randomly partitioned),
        /// Default: consistent_random
        /// </summary>
        public string Partitioner { get; set; }

        /// <summary>
        /// The backoff time in milliseconds before retrying a protocol request.
        /// Default: 100
        /// </summary>
        public int RetryBackoffMs { get; set; }

        /// <summary>
        /// When multiple records are sent to the same partition, the producer will batch them together.
        /// This parameter controls the amount of memory in bytes that will be used for each batch
        /// Setting the batch size too large will not cause delays in sending messages, it will just use more memory for the batches.
        /// Setting the batch size too small will add some overhead because the producer will need to send messages more frequently.
        /// Default: 1,000,000
        /// </summary>
        public int BatchSize { get; set; }

        /// <summary>
        /// Delay in milliseconds to wait for messages in the producer queue to accumulate
        /// before constructing message batches (MessageSets) to transmit to brokers.
        /// Setting higher than 0, will increases latency but also increases throughput.
        /// Default: 0.5
        /// </summary>
        public double LingerMs { get; internal set; } = 0.5;
    }
}
