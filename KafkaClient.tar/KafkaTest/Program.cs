﻿using Confluent.Kafka;
using Infrastructure.Logging.Extensions;
using Infrastructure.MessageBroker.Kafka.Client;
using Infrastructure.MessageBroker.Kafka.Client.Abstracts;
using Infrastructure.Utils.Factory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace KafkaTest
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            Console.Title = "KafkaClient";
            // Create the host service instance
            using IHost host = Host.CreateDefaultBuilder(args)
                                    // Configure the application configuration to load "appsettings.json" (done by default but leave this).
                                    .ConfigureAppConfiguration((hostContext, configuration) =>
                                    {
                                        configuration.AddJsonFile("appsettings.json")
                                                     .Build();
                                    })
                                    // Configure the logging handlers for the host (done by configuration with the "LoggingType" value)
                                    .ConfigureLogging(LoggingExtensions.LoggingFactory)
                                    // Configure the services and dependency injection objects
                                    .ConfigureServices((hostContext, services) =>
                                    {
                                        /*
                                         * All services are configured in the appsettings.json, and loaded using reflection into the dependency
                                         * injection library of .NET Core
                                         */

                                        // Add IMessageBrokerProducer service as singleton
                                        services.AddSingleton<IMessageBrokerProducer>(serviceProvider => new KafkaProducer(serviceProvider));
                                        services.AddSingleton<IMessageBrokerConcumer>(serviceProvider => new KafkaConcumer(serviceProvider));

                                        // Add the hosted service
                                        services.AddHostedService<KafkaTestClient>();
                                    })
                                    // Build the host according to the configured settings
                                    .Build();
            // Start the host
            await host.StartAsync();

            // Wait for the host to shutdown
            await host.WaitForShutdownAsync();
        }
    }
}
