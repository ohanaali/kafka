﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Infrastructure.MessageBroker.Kafka.Client.Abstracts
{
    public interface IMessageBrokerConcumer
    {
        void Initilize(string topicName);

        Task Concume(CancellationToken cancellationToken);
    }
}
