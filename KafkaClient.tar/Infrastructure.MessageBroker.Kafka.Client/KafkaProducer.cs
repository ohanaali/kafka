﻿using Confluent.Kafka;
using Infrastructure.MessageBroker.Kafka.Client.Abstracts;
using Infrastructure.MessageBroker.Kafka.Client.Config;
using Infrastructure.MessageBroker.Kafka.Client.Model;
using Infrastructure.Utils.Config;
using Infrastructure.Utils.Serialization.NewtonsoftJson;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Infrastructure.MessageBroker.Kafka.Client
{
    public class KafkaProducer : IMessageBrokerProducer
    {
        private readonly KafkaClientOptions Options;
        private readonly ILogger Log;
        private readonly ConfigrationMapping ConfMap;

        public IProducer<string, string> ProducerInstance { get; private set; }

        public KafkaProducer(IServiceProvider serviceProvider)
        {
            // Load Configuration
            this.Options = new KafkaClientOptions();
            this.Options.LoadConfigSection<KafkaClientOptions>(serviceProvider.GetService<IConfiguration>());

            // Initialize local members (Log)
            this.Log = serviceProvider.GetService<ILogger<KafkaProducer>>();

            this.ConfMap = new ConfigrationMapping();
        }
        
        public void Initilize()
        {
            ProducerConfig producerConfig = new ProducerConfig
            {
                // Client Config
                BootstrapServers = this.Options.BrokerServers,
                SocketTimeoutMs = this.Options.SocketTimeout,
                ClientId = Dns.GetHostName(),
                ClientRack = this.Options.ClientRack,
                ReconnectBackoffMs = this.Options.ReconnectTimeout,
                // Producer Config
                Acks = this.ConfMap.ClientAcks[this.Options.Acks],
                MessageTimeoutMs = this.Options.KafkaProducer.MessageTimeout,
                MessageSendMaxRetries = this.Options.KafkaProducer.MessageSendMaxRetries,
                Partitioner = this.ConfMap.ProducerPartitioner[this.Options.KafkaProducer.Partitioner],
                RetryBackoffMs = this.Options.KafkaProducer.RetryBackoffMs,
                BatchSize = this.Options.KafkaProducer.BatchSize,
                LingerMs = this.Options.KafkaProducer.LingerMs
            };

            this.ProducerInstance = new ProducerBuilder<string, string>(producerConfig)
                                        .SetErrorHandler((_, e) => this.Log.LogError(e.Reason))
                                        .SetStatisticsHandler((_, json) => this.Log.LogDebug($"Statistics: {json}"))
                                        .Build();

            this.Log.LogDebug($"Producer initialized.");

        }

        public Task Publish<T1,T2>(string topicName, T1 messageValue, T2 messageKey) 
        {
            NewtonsoftJsonSerializer newtonsoftJsonSerializer = new NewtonsoftJsonSerializer();
            string value = newtonsoftJsonSerializer.SerializeObject(messageValue);
            string key = newtonsoftJsonSerializer.SerializeObject(messageKey);

            this.Publish(topicName, value, key);

            return Task.CompletedTask;
        }

        public Task Publish<T>(string topicName, T messageValue)
        {
            NewtonsoftJsonSerializer newtonsoftJsonSerializer = new NewtonsoftJsonSerializer();
            string value = newtonsoftJsonSerializer.SerializeObject(messageValue);
            this.Publish(topicName, value);

            return Task.CompletedTask;
        }

        public Task Publish(string topicName, string messageValue, string messageKey = null)
        {
            try
            {
                // Note: Awaiting the asynchronous produce request below prevents flow of execution
                // from proceeding until the acknowledgement from the broker is received (at the 
                // expense of low throughput).

                Message<string, string> message = new Message<string, string>
                {
                    Key = messageKey,
                    Value = messageValue
                };

                ProducerInstance.Produce(topicName, message, OnMessageProduceHandler());
                //this.Log.LogInformation($"Produced - {this.ProducerInstance.Name}, Topic: {topicName}.");


                //var deliveryReport =  this.ProducerInstance.ProduceAsync(topicName, message);
                //this.Log.LogDebug($"delivered to: {deliveryReport.TopicPartitionOffset}");
                // Since we are producing synchronously, at this point there will be no messages
                // in-flight and no delivery reports waiting to be acknowledged, so there is no
                // need to call producer.Flush before disposing the producer.
            }
            catch (ProduceException<string, string> e)
            {
                this.Log.LogError($"failed to deliver message: {e.Message} [{e.Error.Code}]");
            }

            return Task.CompletedTask;
        }

        private Action<DeliveryReport<string, string>> OnMessageProduceHandler()
        {
            return (deliveryReport) =>
            {
                if (deliveryReport.Error.Code != ErrorCode.NoError)
                {
                    this.Log.LogWarning($"Failed to deliver message: {deliveryReport.Error.Reason}");
                }
                else
                {
                    this.Log.LogDebug($"Produced message to {deliveryReport.TopicPartitionOffset}, Persistence Status: {deliveryReport.Status}, Deliviry Status: {deliveryReport.Error}");
                    //this.Log.LogDebug($"{string.Join(", ", deliveryReport.Headers)}, {deliveryReport.Key}, {deliveryReport.Message}");
                }
            };
        }
    }
}
