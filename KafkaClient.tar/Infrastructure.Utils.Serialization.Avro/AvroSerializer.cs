﻿using Infrastructure.Utils.Serialization.Abstracts;
using System;
using System.Collections.Generic;
using System.Text;
using Confluent.SchemaRegistry;
using Confluent.SchemaRegistry.Serdes;
using Infrastructure.Utils.Serialization.Avro.Config;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Infrastructure.Utils.Config;

namespace Infrastructure.Utils.Serialization.Avro
{
    public class AvroSerializer : ISerializer
    {
        private readonly AvroSerializerOptions Options;
        private readonly ILogger<AvroSerializer> Log;
        private readonly SchemaRegistryConfig SchemaConfig;
        private readonly AvroSerializerConfig SerializerConfig;

        public AvroSerializer(IServiceProvider serviceProvider)
        {
            // Load Configuration
            this.Options = new AvroSerializerOptions();
            this.Options.LoadConfigSection<AvroSerializerOptions>(serviceProvider.GetService<IConfiguration>());

            // Initialize local members (Log, IWebRestApiHandler)
            this.Log = serviceProvider.GetService<ILogger<AvroSerializer>>();

            this.SchemaConfig = new SchemaRegistryConfig()
            {
                Url = this.Options.SchemaRegistryInstance
            };

            this.SerializerConfig = new AvroSerializerConfig()
            {
                BufferBytes = 100
            };
        }




        #region Interface Implementation

        public string AddProperties(string jsonFile, string jsonObjectKey, Dictionary<string, object> keyValuePairs)
        {
            throw new NotImplementedException();
        }

        public string ChangeProperties(string jsonFile, string jsonObjectKey, Dictionary<string, object> keyValuePairs)
        {
            throw new NotImplementedException();
        }

        public T DeserializeObject<T>(string value)
        {
            throw new NotImplementedException();
        }

        public T DeserializeObject<T>(byte[] value, Encoding encoding = null)
        {
            throw new NotImplementedException();
        }

        public object DeserializeObject(string value, Type type)
        {
            throw new NotImplementedException();
        }

        public string GetProperty(object jsonObject, string jsonObjectKey, string keyName)
        {
            throw new NotImplementedException();
        }

        public string GetProperty(string jsonContent, string jsonObjectKey, string keyName)
        {
            throw new NotImplementedException();
        }

        public string GetProperty(object jsonObject, string keyName)
        {
            throw new NotImplementedException();
        }

        public string SerializeObject(object value)
        {
            throw new NotImplementedException();
        }

        public byte[] SerializeObject(object value, Encoding encoding = null)
        {
            throw new NotImplementedException();
        }
    }

    #endregion

    #region Private Methods



    #endregion
}
