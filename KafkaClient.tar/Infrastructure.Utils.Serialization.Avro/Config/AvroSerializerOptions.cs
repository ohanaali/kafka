﻿using Infrastructure.Utils.Config;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Utils.Serialization.Avro.Config
{
    public class AvroSerializerOptions : BaseOptions
    {
        public string SchemaRegistryInstance { get; set; }
    }
}
