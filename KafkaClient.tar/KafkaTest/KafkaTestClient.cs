﻿using Infrastructure.MessageBroker.Kafka.Client.Abstracts;
using KafkaTest.Model;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace KafkaTest
{
    public class KafkaTestClient : IHostedService
    {
        private readonly ILogger<KafkaTestClient> Log;

        private readonly IMessageBrokerProducer MessageBrokerProducer;
        private readonly IMessageBrokerConcumer MessageBrokerConcumer;
        public KafkaTestClient(IMessageBrokerProducer messageBrokerProducer, IMessageBrokerConcumer messageBrokerConcumer, ILogger<KafkaTestClient> logger)
        {
            this.MessageBrokerProducer = messageBrokerProducer;
            this.MessageBrokerConcumer = messageBrokerConcumer;

            this.Log = logger;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            //Producer

            //this.MessageBrokerProducer.Initilize();
            //int i = 0;
            //while (i < 50)
            //{
            //    i++; 
            //    TestMessage testMessage = new TestMessage() { Count = i, Name = $"blabla{i}" };
            //    this.MessageBrokerProducer.Publish<TestMessage, string>($"testTopic", testMessage, $"testkey{i3}");
            //}


            // Concumer

            this.MessageBrokerConcumer.Initilize("testTopic");
            while (!cancellationToken.IsCancellationRequested)
            {
                this.MessageBrokerConcumer.Concume(cancellationToken);
            }

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            //throw new NotImplementedException();
            return Task.CompletedTask;
        }
    }
}
